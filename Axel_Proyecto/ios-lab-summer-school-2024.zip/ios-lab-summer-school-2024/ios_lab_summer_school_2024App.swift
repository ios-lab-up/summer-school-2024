//
//  ios_lab_summer_school_2024App.swift
//  ios-lab-summer-school-2024
//
//  Created by Luis Cedillo M on 26/07/24.
//

import SwiftUI

@main
struct ios_lab_summer_school_2024App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
